interface sayable1 {
    public String say(String name);
}