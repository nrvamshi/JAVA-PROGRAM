@FunctionalInterface
interface Drawable1 {
    public void draw1();
}