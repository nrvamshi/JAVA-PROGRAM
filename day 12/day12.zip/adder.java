interface adder {
    public String call(int a, int b);

}
