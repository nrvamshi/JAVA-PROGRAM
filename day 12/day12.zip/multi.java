interface multi {
    public String mul(int a, int b);

}
