public class roll extends phone {
    int ph() {
        return 1001;
    }

}