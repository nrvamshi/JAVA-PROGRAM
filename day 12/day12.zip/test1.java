class test1 {

    public static void main(String[] args) {
        FIE3 fie = new FIE3();
        fie.say("Hello their");
        fie.doIt();
    }
}