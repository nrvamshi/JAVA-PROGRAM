interface Drawable {
    public void draw();
}