public class add extends name {
    String name1() {
        return "Bangalore";
    }
}