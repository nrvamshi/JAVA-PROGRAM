public class Functional implements sayaable {
    public void say(String msg) {
        System.out.println(msg);
    }
}