public class FIE3 implements Sayable {
    public void say(String msg) {
        System.out.println(msg);
    }
}