class name {
    String na1() {
        return "tommy";
    }
}