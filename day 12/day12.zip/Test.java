public class Test {
    public static void main(String[] args) {
        Functional fie = new Functional();
        fie.say("Hello there");
        fie.show();
        sayaable.hello();
    }
}
