public class phone {
    int ph() {
        return 1245;
    }
}