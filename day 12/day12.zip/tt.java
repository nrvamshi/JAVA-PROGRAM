class tt {
    public static void main(String[] args) {
        name n = new name();
        phone p = new phone();
        roll r = new roll();
        add a = new add();
        System.out.println("Name: " + n.na1());
        System.out.println("Roll Number: " + r.ph());
        System.out.println("Phone Number: " + p.ph());
        System.out.println("Address: " + a.name1());
    }
}